//   copy your firebase config informations
const firebaseConfig = {
  
    apiKey: "AIzaSyB-48Wowh9zNsJa-S8FCRHumlV_CYV8jks",
    authDomain: "fir-d5138.firebaseapp.com",
    databaseURL: "https://fir-d5138-default-rtdb.firebaseio.com",
    projectId: "fir-d5138",
    storageBucket: "fir-d5138.appspot.com",
    messagingSenderId: "97868509332",
    appId: "1:97868509332:web:9511d6c9b524ff860b4481"
 
  
};

// initialize firebase
firebase.initializeApp(firebaseConfig);

// reference your database
var contactFormDB = firebase.database().ref("contactForm");

document.getElementById("contactForm").addEventListener("submit", submitForm);

function submitForm(e) {
  e.preventDefault();

  var fname = getElementVal("fname");
  var lname = getElementVal("lname");
  var Flavours = getElementVal("Flavours");
  var subject = getElementVal("subject");

  saveMessages(fname,lname, Flavours, subject);

  //   enable alert
  document.querySelector(".alert").style.display = "block";

  //   remove the alert
  setTimeout(() => {
    document.querySelector(".alert").style.display = "none";
  }, 3000);

  //   reset the form
  document.getElementById("contactForm").reset();
}

const saveMessages = (fname,lname, Flavours, subject) => {
  var newContactForm = contactFormDB.push();

  newContactForm.set({
    fname: fname,
    lname: lname,
    Flavours: Flavours,
    subject: subject,
  });
};

const getElementVal = (id) => {
  return document.getElementById(id).value;
};
